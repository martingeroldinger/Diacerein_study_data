#GPC (subjects with only one period can be kept; cross-over design is ignored)

setwd("C:/Users/LUCP9843/Documents/statistiek/UHasselt/Rare disease")
library(data.table)
library(dplyr)
library(zoo)

diacerin.b.p.p <- read.table("Diacerein_blister_pain_pruritus.txt", sep="\t", header=TRUE)

#add period
diacerin.b.p.p$period <- as.factor(ifelse(diacerin.b.p.p$Time=="t0"|diacerin.b.p.p$Time=="t2"|diacerin.b.p.p$Time=="t4"|diacerin.b.p.p$Time=="t7", 1, 2))

#exclude pt 1003 who did not start study
diacerin.b.p.p <-diacerin.b.p.p[diacerin.b.p.p$Id != 1003,]

#exclude period 1 for subjects 2010 and 2011, who have missing values (incorrect comparison in GPC) and period 2 for 2006, who has 0 baseline
test <- filter(diacerin.b.p.p, Id==2010 & period==1 | Id==2011 & period==1 | Id==2006 & period==2)
diacerin.b.p.p <- anti_join(diacerin.b.p.p, test)

#change count to numeric variables and order per time per ID
diacerin.b.p.p$Blister_count <- as.numeric(diacerin.b.p.p$Blister_count)

diacerin.b.p.p$Time <- as.factor(diacerin.b.p.p$Time)
diacerin.b.p.p$Time <- factor(diacerin.b.p.p$Time,levels=c("t0","t2","t4","t7","t8","t10","t12","t15")) 
diacerin.b.p.p <- diacerin.b.p.p[order(diacerin.b.p.p$Id,diacerin.b.p.p$Time),]

###########
#2. Simulation - choosing one setting from Appendix
###########

#choosing Simulation Setting 2 - with Power Simulation Setting 1 (see Appendix)

#Reproducibility
set.seed(0)

#Number of runs
RE=5000

#For loop - with specification of simulation setting
for(i in 1:RE){
  
  #second permutation setting (Simulation Setting 2)
  #Permute blocks - Blister_counts random
  blocklength <- 4 # four time points per period, if t2 and t10 are included (3 otherwise)
  blocks <- length(diacerin.b.p.p$Id)/blocklength 
  n <- length(diacerin.b.p.p$Id)
  
  matr.perm = matrix(diacerin.b.p.p$Blister_count, nrow = blocklength, ncol = blocks)
  matr.perm = matr.perm[,sample(1:blocks)]
  diacerin.b.p.p$PermuteBlister_count= c(matr.perm)
  
  #new data set for simulation setting 2 - further manipulations see Appendix B
  diacerin.Sim2 = diacerin.b.p.p
  
  # Power Setting 1 - with only t4 and t12 manipulation
  #which points fulfill the condition
  w3 <- which(diacerin.Sim2$Time=="t4" & diacerin.Sim2$Group=="P")
  w4 <-which(diacerin.Sim2$Time=="t12" & diacerin.Sim2$Group=="P")
  
  nw3<- length(w3)
  nw4<- length(w4)
  
  #Poisson Distribution (Account for Overdispersion - maybe Negative Binomial (NB))
  lambda <- 3
  pois4<-rpois(nw4,lambda)
  pois3<-rpois(nw3,lambda)
  
  #create new Blister count variable, to incorporate these changes
  diacerin.Sim2$SampleBlister_count = diacerin.Sim2$PermuteBlister_count
  
  #manipulating new Blister counts variable 
  diacerin.Sim2$SampleBlister_count[w3] = diacerin.Sim2$PermuteBlister_count[w3] + pois3
  diacerin.Sim2$SampleBlister_count[w4] = diacerin.Sim2$PermuteBlister_count[w4] + pois4


#add column 'red' with 40% reduction of blisters of T0 and T8
diacerin.Sim2$PermuteRed <- ifelse(diacerin.Sim2$Time=="t0" | diacerin.Sim2$Time=="t8", diacerin.Sim2$PermuteBlister_count-diacerin.Sim2$PermuteBlister_count*0.4, NA)
diacerin.Sim2$SampleRed <- ifelse(diacerin.Sim2$Time=="t0" | diacerin.Sim2$Time=="t8", diacerin.Sim2$SampleBlister_count-diacerin.Sim2$SampleBlister_count*0.4, NA)


#if value is NA then take previous value
diacerin.Sim2$PermuteRed <- na.locf(diacerin.Sim2$PermuteRed)
diacerin.Sim2$SampleRed <- na.locf(diacerin.Sim2$SampleRed)

#add column 'bin', which is 1 if there is >40% reduction and 0 if not
diacerin.Sim2$PermuteBin <- ifelse(diacerin.Sim2$PermuteBlister_count<diacerin.Sim2$PermuteRed,1, 0)
diacerin.Sim2$SampleBin <- ifelse(diacerin.Sim2$SampleBlister_count<diacerin.Sim2$SampleRed,1, 0)

#make dataset without T0 and T8
#diacerin.Sim3 <- filter(diacerin.Sim2, Time!="t0" & Time!="t8")
diacerin.Sim2$Id <- as.character(diacerin.Sim2$Id)

diacerin.Sim2$period <- as.factor(ifelse(diacerin.Sim2$Time=="t0"|diacerin.Sim2$Time=="t2"|diacerin.Sim2$Time=="t4"|diacerin.Sim2$Time=="t7", 1, 2))

diacerin.Sim2$N <- i
if (i==1){
    diacerin_b <- diacerin.Sim2
} else {diacerin_b <- rbind(diacerin.Sim2,diacerin_b)
}
}

write.csv(diacerin_b, file = "C:/Users/LUCP9843/Documents/statistiek/UHasselt/Rare Disease/diac_sim_paper.csv", quote = FALSE, row.names = T)



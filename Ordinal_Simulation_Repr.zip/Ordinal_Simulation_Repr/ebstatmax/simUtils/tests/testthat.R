library(testthat)
library(simUtils)

test_check("simUtils")

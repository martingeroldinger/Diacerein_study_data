Documentation for this project is provided in README.md.

This file only exists to meet the formal requirements for Code and Data supplements of submissions to Biometrical Journal, i.e., a Readme file with a .txt file extension.

The entire supplement is also available at github: https://github.com/Lime91/rr-bimj-ordinal

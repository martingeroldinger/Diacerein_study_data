# Copyright (C) 2022  Konstantin Emil Thiel

from .prepare_tables import prepare_power_table_segment
from .prepare_tables import prepare_alpha_error_table
from .write_latex import write_power_table
from .write_latex import write_alpha_error_table
from .write_latex import write_wins_table
from .write_latex import write_pvalue_table

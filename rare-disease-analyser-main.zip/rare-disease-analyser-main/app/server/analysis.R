
source(file.path("analysis", "nparLD.R"), local=T, chdir=T)$value
source(file.path("analysis", "gpc.R"), local=T, chdir=T)$value
